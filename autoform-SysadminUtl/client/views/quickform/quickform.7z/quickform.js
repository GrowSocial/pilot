Template.insertaf2.helpers({
  business: function () {
    return Bizness.find();
  }
});