Template.insertaf.helpers({
  people: function () {
    return People.find();
  }
});